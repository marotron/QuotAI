import re, json, os, subprocess, shutil
from PIL import Image

base = open("liquid-glass/preview/v2c-flat-rings.svg").read()
s = base.replace('  <rect width="1024" height="1024" fill="#FFFFFF"/>\n', '')

# richer gradients
s = re.sub(r'<linearGradient id="tile".*?</linearGradient>', '''<linearGradient id="tile" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#2B2833"/>
      <stop offset="0.5" stop-color="#0E0D12"/>
      <stop offset="1" stop-color="#000000"/>
    </linearGradient>''', s, count=1, flags=re.S)
s = re.sub(r'<linearGradient id="blue".*?</linearGradient>', '''<linearGradient id="blue" gradientUnits="userSpaceOnUse" x1="560" y1="250" x2="360" y2="720">
      <stop offset="0" stop-color="#B8F6FF"/>
      <stop offset="0.45" stop-color="#3DC4FF"/>
      <stop offset="1" stop-color="#1F6CFF"/>
    </linearGradient>
    <linearGradient id="ringGrad" gradientUnits="userSpaceOnUse" x1="320" y1="220" x2="760" y2="820">
      <stop offset="0" stop-color="#FFFFFF"/>
      <stop offset="1" stop-color="#F0ECFF"/>
    </linearGradient>''', s, count=1, flags=re.S)
s = s.replace('fill="none" stroke="#FFFFFF" stroke-width="34" stroke-linecap="round"', 'fill="none" stroke="url(#ringGrad)" stroke-width="34" stroke-linecap="round"')
assert 'url(#ringGrad)' in s


# --- black background + bigger artwork ---
s = s.replace('stroke="#000" stroke-opacity="0.08" stroke-width="78"', 'stroke="#FFFFFF" stroke-opacity="0.10" stroke-width="78"')
import re as _re
glow = _re.search(r'\n\s*<rect x="40" y="40" width="944" height="944" fill="url\(#tileGlow\)"/>', s).group(0)
sheen = _re.search(r'\n\s*<rect x="40" y="40" width="944" height="944" rx="210" fill="url\(#sheen\)"/>', s).group(0)
SCALE = 1.16
s = s.replace(glow, glow + f'\n    <g transform="translate(512 512) scale({SCALE}) translate(-512 -512)">', 1)
s = s.replace(sheen, '\n    </g>' + sheen, 1)

# --- contrast pass ---
s = s.replace('stroke="#000" stroke-opacity="0.08" stroke-width="78"', 'stroke="#12083F" stroke-opacity="0.28" stroke-width="78"')
s = s.replace('stroke="#1B1150" stroke-opacity="0.35" stroke-width="5"', 'stroke="#0E0640" stroke-opacity="0.55" stroke-width="5"')
for a, b in [("#D6F0FF", "#EAF9FF"), ("#3E8FD6", "#2A80E0"), ("#2C6AB8", "#17479E")]:
    s = s.replace(f'stop-color="{a}"', f'stop-color="{b}"')
s = s.replace('stop-color="#FFFFFF" stop-opacity="0.22"/><stop offset="1" stop-color="#FFFFFF" stop-opacity="0"/>',
              'stop-color="#FFFFFF" stop-opacity="0.10"/><stop offset="1" stop-color="#FFFFFF" stop-opacity="0"/>')
s = s.replace('<stop offset="0" stop-color="#FFFFFF" stop-opacity="0.32"/>', '<stop offset="0" stop-color="#FFFFFF" stop-opacity="0.18"/>')
open("pack/quotai-icon.svg","w").write(s)

# split body (everything between </defs> and </svg>) to re-frame for macOS / iOS
defs_end = s.index("</defs>") + len("</defs>")
head, body = s[:defs_end], s[defs_end:s.rindex("</svg>")]

# macOS: Apple grid, 824px body centred on a 1024 canvas, with soft drop shadow
k = 824/944
mac = head.replace("</defs>", '''  <filter id="macShadow" x="-10%" y="-10%" width="120%" height="125%">
      <feGaussianBlur in="SourceAlpha" stdDeviation="14"/><feOffset dy="12" result="o"/>
      <feFlood flood-color="#000" flood-opacity="0.30"/><feComposite in2="o" operator="in" result="sh"/>
      <feMerge><feMergeNode in="sh"/><feMergeNode in="SourceGraphic"/></feMerge>
    </filter>
  </defs>''') + f'\n  <g filter="url(#macShadow)"><g transform="translate(100 100) scale({k:.6f}) translate(-40 -40)">{body}</g></g>\n</svg>'
open("pack/quotai-icon-macos.svg","w").write(mac)

# iOS: full-bleed square, the system applies the corner mask
kb = 1024/944
ios_body = body.replace('clip-path="url(#sq)"', 'clip-path="url(#full)"')
ios_body = re.sub(r'\s*<rect x="41\.5"[^>]*/>', '', ios_body)
ios = head.replace("</defs>", '  <clipPath id="full"><rect x="40" y="40" width="944" height="944"/></clipPath>\n  </defs>') + \
      f'\n  <g transform="translate(512 512) scale({kb:.6f}) translate(-512 -512)">{ios_body}</g>\n</svg>'
open("pack/quotai-icon-ios.svg","w").write(ios)

def render(svg, png, size=1024):
    subprocess.run(["google-chrome","--headless=new","--no-sandbox","--disable-gpu","--hide-scrollbars",
                    "--default-background-color=00000000",f"--window-size={size},{size}",
                    f"--screenshot={os.path.abspath(png)}", "file://"+os.path.abspath(svg)],
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)

render("pack/quotai-icon.svg", "pack/_master.png")
render("pack/quotai-icon-macos.svg", "pack/_mac.png")
render("pack/quotai-icon-ios.svg", "pack/_ios.png")
master = Image.open("pack/_master.png").convert("RGBA")
mac = Image.open("pack/_mac.png").convert("RGBA")
ios = Image.open("pack/_ios.png").convert("RGB")   # iOS app icons must have no alpha

def rs(im, n): return im.resize((n, n), Image.LANCZOS)

# PNG sizes
os.makedirs("pack/png", exist_ok=True)
for n in [16, 32, 48, 64, 128, 256, 512, 1024]:
    rs(master, n).save(f"pack/png/quotai-{n}.png")

# macOS AppIcon.appiconset + .icns
mset = "pack/macOS/AppIcon.appiconset"; os.makedirs(mset, exist_ok=True)
images = []
for pt in [16, 32, 128, 256, 512]:
    for sc in [1, 2]:
        fn = f"icon_{pt}x{pt}{'@2x' if sc == 2 else ''}.png"
        rs(mac, pt*sc).save(f"{mset}/{fn}")
        images.append({"filename": fn, "idiom": "mac", "scale": f"{sc}x", "size": f"{pt}x{pt}"})
json.dump({"images": images, "info": {"author": "xcode", "version": 1}}, open(f"{mset}/Contents.json","w"), indent=2)
mac.save("pack/macOS/AppIcon.icns", sizes=[(16,16),(32,32),(64,64),(128,128),(256,256),(512,512),(1024,1024)])

# iOS AppIcon.appiconset (single 1024 universal)
iset = "pack/iOS/AppIcon.appiconset"; os.makedirs(iset, exist_ok=True)
ios.save(f"{iset}/AppIcon-1024.png")
json.dump({"images": [{"filename": "AppIcon-1024.png", "idiom": "universal", "platform": "ios", "size": "1024x1024"}],
           "info": {"author": "xcode", "version": 1}}, open(f"{iset}/Contents.json","w"), indent=2)

# Web / Windows
os.makedirs("pack/web", exist_ok=True)
master.save("pack/web/favicon.ico", sizes=[(16,16),(32,32),(48,48)])
rs(ios, 180).save("pack/web/apple-touch-icon.png")
rs(master, 192).save("pack/web/icon-192.png"); rs(master, 512).save("pack/web/icon-512.png")

# Menu bar template (mono)
os.makedirs("pack/menubar", exist_ok=True)
shutil.copy("export/quotai-icon-mono.svg", "pack/menubar/MenuBarIconTemplate.svg")
render("pack/menubar/MenuBarIconTemplate.svg", "pack/_mono.png")
mono = Image.open("pack/_mono.png").convert("RGBA")
rs(mono, 18).save("pack/menubar/MenuBarIconTemplate.png"); rs(mono, 36).save("pack/menubar/MenuBarIconTemplate@2x.png")

# preview sheet
sheet = Image.new("RGB", (1300, 460), "#F2F1F7")
sheet.paste(rs(mac, 400), (20, 30), rs(mac, 400))
ios_r = rs(ios, 360); m = Image.new("L", (360, 360), 0)
from PIL import ImageDraw
ImageDraw.Draw(m).rounded_rectangle([0,0,359,359], radius=80, fill=255)
sheet.paste(ios_r, (460, 50), m)
x = 860
for n in [128, 64, 32, 16]:
    sheet.paste(rs(mac, n), (x, 230 - n//2), rs(mac, n)); x += n + 30
sheet.save("pack/preview.png")
for f in ["_master.png","_mac.png","_ios.png","_mono.png"]: os.remove("pack/"+f)
